const source = [
    {
        "type": "text",
        "icon": "ico-fiocco",
        "text": "Inizia la tua settimana di festeggiamenti! Copia il link per guardare cosa c'è per te oggi! https://www.youtube.com/watch?v=blRWaikEu5A"
    },
    {
        "type": "text",
        "icon": "ico-fiocco",
        "text": "A te che mi proteggi dalla vita che m’hai donato, ringrazio per ogni insegnamento dato. M’hai atteso, partorito… amato sempre con lo stesso sorriso. Per te ho solo parole sincere, quelle che vengono dal cuore: Mamma sei il mio unico vero amore!"
    },
    {
        "type": "image",
        "icon": "ico-fiocco",
        "title": "polar bear",
        "url": "images/polar-bear.gif"
    },
    {
        "type": "text",
        "icon": "ico-fiocco",
        "text": "C’è una gran quantità di cose belle, che Dio ci può concedere due volte; ma la mamma è cosa tanto grande, che ce la dà una volta sola. (Harriet Beecher Stowe)"
    },
    {
        "type": "image",
        "icon": "ico-fiocco",
        "title": "pingu",
        "url": "images/pingu-mom.gif"
    },
    {
        "type": "text",
        "icon": "ico-fiocco",
        "text": "Lo sapevi? Secondo alcuni studi, furono gli antichi greci i primi ad utilizzare le candeline per compleanno. In Grecia le candeline venivano accese in onore di Artemide, dea della caccia. A lei venivano offerti dei dolci decorati con dei lumini, così da renderli luminosi come la luna, simbolo di Artemide."
    },
    {
        "type": "image",
        "icon": "ico-fiocco",
        "title": "rory e lorelai",
        "url": "images/una-mamma-per-amica.gif"
    }
];